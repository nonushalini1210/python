def main():
      print('\n'*50)
      str01 = ' '
      str01=input('enter characters -> ')
      str02 = str01.lstrip()
      print('left:',str02 + '|')
      print(' length left is: ',len(str01), ' after ', len(str02),'\n')
      ans = input('hit enter to continue')
      
      str02 = str01.rstrip()
      print('right:',str02 + '|')
      print(' length right is: ',len(str01), ' after ', len(str02),'\n')
      ans = input('hit enter to continue')
      
      str02 = str01.strip()
      print('both:',str02 + '|')
      print(' length both is: ',len(str01), ' after ', len(str02))
main()
