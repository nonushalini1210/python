 
import numpy as arr 
  
z = arr.zeros([3, 3, 3]) 
print("\nMatrix z : \n", z)
h = 1
for a in range(3):
   for b in range(3):
      for c in range(3):
          z[a][b][c] =  h           
          h = h + 1
print(' --------------- ')
print("\nMatrix z : \n", z)
