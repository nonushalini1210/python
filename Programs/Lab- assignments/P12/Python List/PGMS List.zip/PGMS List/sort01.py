def main():
      numblist = [5,15,25,66,33,22.9,1,99,88,55.5,2,44]
      #numblist=['ggg','ddd','www','aaa']
      #numblist=['ggg',25,30,'ddd','www',99,'aaa']
      print(' # of elements-> ',len(numblist))
      print(numblist)
      print('-------')
      numblist.sort()
      print(numblist)
main()
