# more examples
# string compare
a = 'one'
b = 'two'
if a > b:
    z='true'
else:
    z='false'
print(" a ='one' b = 'two'   a > b   true or false")
bb = input('\nwhat is the results, hit enter to see\n')
print('  a > b  is ', z)
print('-----------------\n\n\n')
if a > 'five':
    z='true'
else:
    z='false'
print(" a = 'one'    a > 'five'  true or false ")
bb = input('\nwhat is the results, hit enter to see\n')
print("  a > 'five'  is ", z)
print('-----------------\n\n\n')
if a > 'any':
    z='true'
else:
    z='false'
print(" a = 'one'    a > 'any'  true or false ")
bb = input('\nwhat is the results, hit enter to see\n')
print("  a > 'any'  is ", z)
print('-----------------')    
