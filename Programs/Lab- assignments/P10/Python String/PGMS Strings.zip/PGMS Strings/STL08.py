def chkupper(ss):
    if (ss.isupper()):
        rr ='yes'
    else:
        rr = 'no'
    return rr
def chklower(ss):
    if (ss.islower()):
        rr = 'yes'
    else:
        rr = 'no'
    return rr
def chkspace(ss):
    if (ss.isspace()):
        rr = 'yes'
    else:
        rr = 'no'
    return rr
def main():
      ans = 'y'
      while (ans.upper() =='Y'):
            print('\n'*5)
            str01 = ' '
            str01=input('enter characters -> ')
            al = len(str01)
            print(' input length is: ',al)
            als = str01.strip()
            alls = len(als)
            print(' input length after strip is: ',alls)
            aa=chkupper(str01)
            print('input upper case -> ',aa)
            bb=chklower(str01)
            print('input lower case ->',bb)
            cc=chkspace(str01)
            print('input is blank ->',cc)
            ans = input('\nAnother test y/n -> ')
      print('\n ---done---')
main()
