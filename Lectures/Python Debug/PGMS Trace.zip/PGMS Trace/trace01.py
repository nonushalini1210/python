def valid(chk):
    if len(chk) == 0:
        return -1
    fchk = float(chk)
    if fchk < 0:
        return -1
    return fchk
    
def trace1():
    print('payroll calculator')
    hours = input('enter hours: ')
    rate = input('hourly rate; ')
    fhours = valid(hours)
    if fhours > 0:
        frate = valid(rate)
        if frate > 0:
            pay = fhours * frate
        else:
            print('invalid hours')
    else:
        print('invalid rate')
    print('Pay; ',pay) 
trace1()
