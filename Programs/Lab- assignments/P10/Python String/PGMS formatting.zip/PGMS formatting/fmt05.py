nm = 101.6
print('Number is: $%.2f' % (nm))
print
fn =  2.99
ln = 99555.06875
print('First number is $%.6f' %(fn))
print('Last number is: $%.6f' %(ln))
print('Name: $%.2f  $%.2f'% (fn,ln))
