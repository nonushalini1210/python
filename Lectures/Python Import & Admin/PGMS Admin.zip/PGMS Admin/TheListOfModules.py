# 3.7
import keyword
def main():
    print( help('modules'))
    return
main()
