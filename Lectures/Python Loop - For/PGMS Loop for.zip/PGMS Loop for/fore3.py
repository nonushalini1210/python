print('\n'*3)

for x in range(1,20,3):
    print(' x -> ',x)
print('\n'*3)
input('hit enter to continue')
print('\n'*3)

for x in range(20,0,-5):
    print(' x -> ',x)
    
print('\n'*3)
