import datetime
def main():
       x = datetime.datetime.now()
       print(x)
       return
main()
