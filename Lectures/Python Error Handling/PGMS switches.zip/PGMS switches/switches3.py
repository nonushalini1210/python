
## input routine
def input1(msg):
    indata = input(msg)
    return indata

## Processing
def process1():
    msg = "Enter a number: "
    num = input1(msg)
    (err,b) = valid1(num)
    return (err,b)

##  validation 
def valid1(num):
    err = 0
    b = 0
    try:
        b = float(num)
        if (b >0):
            err = 0
        else:
            err = 1
    except:
        err = 2
    return (err,b)

## main line
def main():
    ans = 'y'
    total = 0
    while(ans.upper() == 'Y'):
        (err,num) = process1()
        if (err==0):
            print('Number: ',num)
            total = total + num
        else:
            if err ==1:
                print(' input cannot be negative')
            else:
                print(' ***** Invalid INPUT')
        msg = 'Continue (y/n)? '    
        ans = input1(msg)
    print('-------')
    print('total is: ', total)
    return
main()
