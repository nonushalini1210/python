def spacer():
    z=input('hit enter key to continue')
    print('--------------')
    return    
def main():
    for a in range(5):
        print('a ->',a)
    spacer()
    for b in range(1,10):
        print('b ->',b)
    spacer()
    for c in range(0,20,4):
        print('c ->',c)
    spacer()
    for d in range(30,5,-5):
        print('d ->',d)
    spacer()
    #m=0.0
    for m in range(1.0,5.0, .5):
        print('m ->',m)        
    
main()
