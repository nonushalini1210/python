nm = 101.02
print('Numbr is: {:6.2f}'.format(nm))
print
fn = 202.0588
ln = 555.0000075
print('First number is {:3.1f}'.format(fn))
print('Last number is: {:3.1f}'.format(ln))
print('Name: {:6.2f} {:6.2f}'.format(fn,ln))
