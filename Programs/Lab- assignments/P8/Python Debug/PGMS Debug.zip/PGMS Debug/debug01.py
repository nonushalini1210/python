def blkln():
      print('\n'*a)
      return
def main():
      blkln(a)
      print('this should work')
      aa = float(input('enter aquanity: ')
               print('number is',aa)
      blkln()
      print(' Paymaent amount is: ', pamt)
      pamt=int(input('enter payment'))
      print('Balance is: ',balance
      balance = balance - pamt
main()
