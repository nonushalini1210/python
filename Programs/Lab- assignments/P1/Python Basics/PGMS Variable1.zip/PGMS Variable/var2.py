total01 = 100
total02 = 22.44
head = 'This is a report TITLE'
print(head)
print('Total #1: ',total01)
print('Total #2: ',total02)
