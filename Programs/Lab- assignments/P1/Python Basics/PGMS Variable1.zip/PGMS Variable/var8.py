Fname = "Johnny"
Lname = 'Five'
Wname = Fname  + ' '+ Lname
print (Wname)
