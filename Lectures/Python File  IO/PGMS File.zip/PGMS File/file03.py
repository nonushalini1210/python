def main():
    print('pgm start')
    filenameout ='c:/data6/pgmdata/ph2.txt'
    outfile = open(filenameout,'w')
    outfile.write(' john locke\n')
    outfile.write('david hume\n')
    outfile.write('Fast eddy burke\n')
    outfile.close()
    print('pgm done')
main()
