def sub1():
    global x
    #x = 1000
    print('s1 ',x)
    x=x+1
    print('s2 ',x)
    x=x+1
    return
x=5
sub1()
print('M1 ',x)
x=x+2
sub1()
print('M2 ',x)
x=x+2
sub1()

