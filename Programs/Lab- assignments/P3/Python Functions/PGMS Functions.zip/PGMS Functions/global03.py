def sub1():
    global x,y
    print('S1 ',x)
    x=x+1
    print('S2 ',x)
    x=x+1
    y=y+1
    return
def main():
    global x,y
    x=5
    y=10
    sub1()
    print('M1 ',x)
    x=x+2
    sub1()
    print('M2 ',x)
    x=x+2
    sub1()
main()

