# basic array characteristics 
import numpy as np 

arr = np.array( [[ 1, 2, 3], 
                 [ 4, 2, 5]] ) 
# ---  type of arr object 
print("Array is of type: ", type(arr)) 
# --- array dimensions (axes) 
print("No. of dimensions: ", arr.ndim) 
# ---   shape of array 
print("Shape of array: ", arr.shape) 
# --- size (total number of elements) of array 
print("Size of array: ", arr.size) 
# --- type of elements in array 
print("Array stores elements of type: ", arr.dtype) 

