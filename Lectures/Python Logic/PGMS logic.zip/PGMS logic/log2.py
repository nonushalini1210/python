A = 5
B = 6
C = 7
D = 2
E = 6
input('hit enter to continue')
if (A == B) and (A ==C):
    z = 'True'
else:
    z = 'False'
print('(A == B) and (A ==C)  ', z)
if (A > B) and (B > C) and ( C > D):
    z = 'True'
else:
    z = 'False'
print('(A > B) and (B > C) and ( C > D) ', z)
if (B == E)  and (C > E):
    z = 'True'
else:
    z = 'False'
print('(B == E)  and (C > E) ', z)
if (A != E) and ( C == 7):
    z = 'True'
else:
    z = 'False'
print('(A != E) and ( C == 7) ', z)
if (B > E) or (C > A):
    z = 'True'
else:
    z = 'False'
print('(B > E) or (C > A)  ', z)
if (A == E) or (B == D) or (E == B):
    z = 'True'
else:
    z = 'False'
print('(A == E) or (B == D) or (E == B)  ', z)
if (A!= D) or (B!= E) or (B ==5):
    z = 'True'
else:
    z = 'False'
print('(A!= D) or (B!= E) or (B ==5) ', z)
if (D == 2) or (C == 7) or (B == E):
    z = 'True'
else:
    z = 'False'
print('(D == 2) or (C == 7) or (B == E) ', z)
if not (E==6):
    z = 'True'
else:
    z = 'False'
print('not (E==6) ', z)

















