print('\n'*3)

for x in range(5):
    print(' x -> ',x)

print('\n'*3)
