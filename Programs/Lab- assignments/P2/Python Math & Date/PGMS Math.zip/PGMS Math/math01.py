def main():
    print('\n'*5)
    a = 22/3
    print('22/3= ',a)
    print
    b = 22//3
    print('22//3= ',b)
    print
    c = 22%3
    print('22%3= ',c) 
    return
main()
