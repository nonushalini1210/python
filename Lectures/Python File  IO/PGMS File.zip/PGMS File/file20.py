# --------------------
# program: file20
# --------------------
import datetime
#---------------------------
#   open files
#---------------------------
def openfiles():
    code = 0
    try:
        filein ='C:/data6/pgmdata/testfile8.txt'
        datafilein = open(filein,'r')    # open inout
    except:
        code = 1
    try:
        fileout ='C:/data6/pgmdata/testfile7out.txt'
        datafileout1 = open(fileout,'w')    # open output
    except:
        code = 2
    return(datafilein,datafileout1, code)
#---------------------------------------
#  close files
#---------------------------------------
def closefiles(fi,fo):
    fi.close()          # close input
    fo.close()          # close output
    return
# ------------------------------
#   Error message routine
#---------------------------------
def errorchk(code):
    msg='unknown file processing error'
    if code == 1:
        msg = ' error - input file'
    else:
        code == 2
        msg = 'error - output file'
    return msg
#---------------------------------
#   valid record
#---------------------------------
def validline(line):
    msg = ''
    if line.count(',') != 3:    # Correct number of field (4)
        msg = 'Record has invalid number of fields'
    return msg
#----------------------------------------
#   process record
#---------------------------------------
def process(line,rcdcnt,outcnt,infile,outfile):
    while line != '':
        rcdcnt = rcdcnt + 1     #  count input
        print(line)
        msg = validline(line)     # - validate the record
        if msg =='':
            (a,b,c,d) =line.split(',')   # extract fields
            print(' A is: ' + a)
            print(' B is: ' + b)
            print(' C is: ' + c)
            print(' D is: ' + d)       
            newline = a + ',' + d +'\n'      #  build output record
            outfile.write(newline)           # write record
            outcnt = outcnt + 1              # count output
            line=infile.readline()           # get next record
        else:
            print(msg)
            print('ERROR record: ',line)
            print(' * * Program terminated due to errors')
            line=''
    return (rcdcnt,outcnt)
#-------------------------------------
#  main
#--------------------------------------
def file20():
    print('Program started: ',datetime.datetime.now())
    msg = ''
    rcdcnt = 0
    outcnt = 0
    line = ''
    newline = ''
    (infile,outfile,code)=openfiles()
    if code == 0:                 # files good?
        line=infile.readline()    # get first record
        # ----  process the record
        (rcdcnt,outcnt)=process(line,rcdcnt,outcnt,infile,outfile)
    else:
        errorchk(code)
        print(msg)
    print('number of records: ',rcdcnt)
    print('number of record written: ',outcnt)
    print('Program ended: ',datetime.datetime.now()) 
    closefiles(infile,outfile)
file20()
#----------------------------
#  end of program
#-----------------------------


