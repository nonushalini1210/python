def calculate():
    gp = 0.0
    pay = float(input('enter pay rate: '))
    hrs = float(input('enter hours: '))
    gp = pay * hrs
    print('Gross pay: ',gp)
    return
def main():
    print(' Program start')
    ans = 'y'
    while ((ans == 'y') or (ans == 'Y')):    
        calculate()
        print('------------')        
        print(' y = yes    n = no')
        ans = input('Continue y/n -> ')
    print(' –done—')
main()
