def clrscn(a):
    print('\n' * a)
    return

def main():
    xx = 20
    print(' --top--')
    clrscn(xx)
    print('--bottom--')
    return

main()
