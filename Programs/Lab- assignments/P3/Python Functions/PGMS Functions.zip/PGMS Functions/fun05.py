
def getdata():
    a = float(input(" Enter a number; "))
    return a 
def showdata(b):
    print('value is: ',b)
    c = b  * 2
    return c
def main():
    b = getdata()
    c = showdata(b)
    print(' c is: ',c)
    return
main()
