def main():
     # set up dictionary
     dt01 = { 1: 'one',
              7: 'seven',
              2: 'two',
              3: 'three',
              4: 'four',
              5: 'five'}
     print('Dictionary example')
     print(dt01)
     v01 = dt01[7]
     print('Value for 7 is: ',v01)
     a=4
     v02 = dt01[a]
     print('Value for ', a, ' is: ',v02)
main()

