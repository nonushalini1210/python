nm = 101.6
print('Numbr is: ${:,.2f}'.format(nm))
print
fn = 202.998
ln = 99555.009007
print('First number is ${:,.2f}'.format(fn))
print('Last number is: ${:,.2f}'.format(ln))
print('Name: ${:,.2f}  ${:,.2f}'.format(fn,ln))
