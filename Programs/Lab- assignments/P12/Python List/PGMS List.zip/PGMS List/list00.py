def main():
    numb = [2,4,6,8]
    print(numb)
    letter = ['aaa', 'bbb', 'ccc']
    print(letter)
    mixed = [6,'c',5,'d']
    print(mixed)
    mix02 = [1, 'a', 1.5, 'b']
    print(mix02)
main()
