import time
def sel001():
    print(' \nselection 1\n')
    return
def sel002():
    print(' \nselection 2\n')
    return
def displaymenu():
    print('\n'*25)
    print(' select action ')
    print('----------------')
    print ('1  one')
    print ('2  two')
    print(' ')
    print ('9   Quit\n')
    return
def menu():
    selection = 0

    displaymenu()
    selection = input(' Select 1,2 or 9 [to quit]: ')
    if (selection =='1' ):
        sel001()
    elif (selection == '2'):
        sel002()
    elif (selection == '9'):
        return
    else:
        print(' invalid selection, try again')
    return
def main():
    menu()
    return
main()
