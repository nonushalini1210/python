def getnumb():
    z = 0
    while(z==0):
        try:
            aa = float(input('enter a number -> '))
            break
        except:
            print('input not a number')
    return aa
def main():
    numblist = []
    for x in range(0,5,1):
        aa = getnumb()
        numblist.append(aa)
        print(numblist)
    print('-------')
    print(numblist)
main()
