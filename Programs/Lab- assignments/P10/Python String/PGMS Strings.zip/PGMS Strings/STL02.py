print('\n'*5)
str01 = 'The fox is back'
str02 = 'tt'
if str02  not in str01:
    print('True')
else:
    print('False')
print('\n'*5)
