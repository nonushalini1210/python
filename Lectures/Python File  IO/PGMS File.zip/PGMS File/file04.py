def main():
    print('pgm started')
    filenamein ='c:/data6/pgmdata/testfile1.txt'
    rcdcnt = 0
    infile = open(filenamein,'r')
    line=infile.readline()
    while (line != ""):
        rcdcnt = rcdcnt+1
        line = line.strip()
        print (line)
        line=infile.readline()
    infile.close()
    print('\n'+ 'Number of records read: ' + str(rcdcnt))
    print (' ---done')
main()
