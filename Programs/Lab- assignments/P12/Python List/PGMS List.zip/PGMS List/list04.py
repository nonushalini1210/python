def main():
    numb = [0] * 5
    x = 0
    while (x < 5):
        numb[x] = float(input('Enter number: '))
        x = x + 1
    print(numb)
    len1 = len(numb)
    print('number of elements ->',len1)
    ans = input('enter to continue')
    print('\n',numb)
    for z in range (len1):
        print('Element ',z, ' is ', numb[z])
main()

