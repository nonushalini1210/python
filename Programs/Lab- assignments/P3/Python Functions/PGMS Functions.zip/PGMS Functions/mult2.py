def addsubt(x,y):
    a = x + y
    b = x - y
    return (a, b)
def main():
    numb1 = float(input('enter number ->'))
    numb2 = float(input('enter number ->'))           
    (tot1,tot2) = addsubt(numb1,numb2)
    print('total is -> ',tot1)
    print('diff is -> ',tot2)
main()
