import numpy as np
 
array1d = np.array([1, 2, 3, 4, 5, 6])
array2d = np.array([[1, 1, 1], [2, 2, 2]])
array3d = np.array([[[1, 1, 1], [2, 2, 2]], [[3, 3, 3], [4, 4, 4]]])
 
print(' 1 d array\n',array1d)
 
print('----------')
print(' 2 d array \n',array2d)
 
print('------')
print(' 3 d array \n',array3d)

