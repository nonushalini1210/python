def main():
    numb = [0] * 5
    for x in range(0,5,1):
        numb[x] = float(input('Enter number: '))
        print('number: ',numb[x], 'is at ',x)
    len1 = len(numb)
    print('\nnumber of elements ->',len1,'\n')
    print(numb)
main()
