def ascn():
    print(' *************** ')
    print(' *             * ')
    print(' *************** ') 
    return

def main():
    ascn()
    print(' This is a line')
    ascn()
    print(' Line two')
    ascn()
main()
