def main():
    print('\n'*2)
    for x in range(1,10):
        print(' x-> ',x)
    else:
        print(' end of loop')
    print('----done')
main()
