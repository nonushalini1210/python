def main():
    print('pgm started')
    filenamein ='c:/data6/pgmdata/testfile1.txt'
    rcdcnt = 0
    with open(filenamein,'r') as infile:
        line=infile.readline()
        while line:
            rcdcnt = rcdcnt+1
            line = line.strip()
            print (line)
            line=infile.readline()
    print('\n'+ 'Number of records read: ' + str(rcdcnt))
    print (' ---done')
main()
