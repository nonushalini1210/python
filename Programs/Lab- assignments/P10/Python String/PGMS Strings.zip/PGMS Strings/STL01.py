print('----------')
print
print('X' * 50)
