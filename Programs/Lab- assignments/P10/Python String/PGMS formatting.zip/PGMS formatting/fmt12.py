nm = 101.6
print('Numbr is: {:f}'.format(nm))
print
fn = 202.99 
ln = 555.00007
print('First number is {:f}'.format(fn))
print('Last number is: {:f}'.format(ln))
print('Name: {:f} {:f}'.format(fn,ln))
