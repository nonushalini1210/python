nm = 101.6
print('Number is: %f' %(nm))
print
fn = 202.99 
ln = 555.00007
print('First number is %f' %(fn))
print('Last number is: %f' %(ln))
print('Name: %f %f'% (fn,ln))
