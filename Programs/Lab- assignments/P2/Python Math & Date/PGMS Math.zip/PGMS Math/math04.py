import math
def main():
    MM = 9
    RR = -3
    VV = 5
    EE = 2
    AA = SquareRoot(MM)
    print('Square root of ',MM, ' is ', AA)
    AA = RaiseToPower(VV,EE)
    AA = AbsoluteValue(RR)

main()

