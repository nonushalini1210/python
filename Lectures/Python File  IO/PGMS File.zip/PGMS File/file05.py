def main():
    eofm = "\n"
    filename ='c:/data6/pgmdata/ph2.txt'
    appfile = open(filename, 'a')
    print (' enter three names: ')
    name1 = input('Name #1: ')
    name2 = input('Name #2: ')
    name3 = input('Name #3: ')
    appfile.write(name1 + eofm)
    appfile.write(name2 + eofm)
    appfile.write(name3 + eofm)
    appfile.close()
main()
