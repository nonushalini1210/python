def valid(chk):
    if len(chk) == 0:
        return -1
    fchk = float(chk)
    if fchk < 0:
        return -1
    return fchk
    
def trace1():
    print('payroll calculator')
    hours = input('enter hours: ')
    rate = input('hourly rate; ')
    fhours = valid(hours)
    print('a  ')
    if fhours > 0:
        frate = valid(rate)
        print('b   ')
        if frate > 0:
            print('c')
            pay = fhours * frate
        else:
            print('d')
            print('invalid hours')
    else:
        print('e')
        print('invalid rate')
    print('f')
    print('Pay; ',pay) 
trace1()
