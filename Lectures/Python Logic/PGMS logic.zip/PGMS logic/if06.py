def main():
    m=int(input('enter a number -> '))
    if(m>=10):
        print('Greater than 10')
    elif  (m>=5):
        print('greater than 5')
    else:
        print('less than 5')
main()
