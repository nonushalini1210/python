def main():
    length = input('Enter length: ')
    height = input('Enter height: ')
    area = 0.0
    try:
        area=(length) * (height)
    except ValueError:
        print(' value error')
    except TypeError:
        print(' type error')
    except:
        area = -1
    print(' Area is -> ', area)
main()
