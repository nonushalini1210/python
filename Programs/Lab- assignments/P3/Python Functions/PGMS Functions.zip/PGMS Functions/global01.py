 
def sub1():
    x=10
    print('s1 ',x)
    x=x+1
    print('s2 ',x)
    x=x+1
    return
def main():
    x=1
    sub1()
    print('M1 ',x)
    x=x+2
    sub1()
    print('M2 ',x)
    x=x+2
    sub1()
main()
