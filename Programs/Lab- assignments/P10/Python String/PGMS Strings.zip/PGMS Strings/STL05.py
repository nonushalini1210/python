def main():
       sn1 =   'abcdefghijklmnopqrstuvwxyz'
       sn2 =   '!@#$%^&*()_+-={}[]:;<>?,.|'
       str01 = 'The fox is back'       
       for x in range(1,4,1):
           if x == 2:
               str01 = sn1
           if x == 3:
               str01 = sn2
          
           ans = input('hit enter to continue')
           print(str01)
           a = 4
           b = 7
           
           str02 = str01[a:b]
           print('text at position 4 to position 7 is: ',str02)
           ans = input('hit enter to continue')
           
           str03 = str01[:3]
           print('the first 3 character are: ',str03)
           ans = input('hit enter to continue')
           
           str04 = str01[11:]
           print('all text from postion 11 to end of string: ',str04)
           print('\n')
       return
main()

