def main():
    filename ='c:/temp/testfile5.txt'
    rcdcnt = 0
    datafile = open(filename,'r')
    line=datafile.readline()
    print('here are the sales amount: ')
    while line != '':
        print(' line before split: ' + line)
        v1 =line.split(',')
        numbel = len(v1)
        print('number of elements: ',numbel)
        print('v1: ',v1)
        print(' A is: ' + v1[0])
        print(' B is: ' + v1[1])
        print(' C is: ' + v1[2])   
        print(' B  v1[1] = ',v1[1], '\n')      
        line=datafile.readline()
        rcdcnt = rcdcnt+1
    datafile.close()
    print('\n'+ 'Number of records read: ' + str(rcdcnt))
    print (' ---done')
main()
        
