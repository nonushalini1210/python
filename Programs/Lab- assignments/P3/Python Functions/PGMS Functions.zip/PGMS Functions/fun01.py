def ascn():
    print(' *************** ')
    return

def main():
    print(' --top--')
    ascn()
    print('--bottom--')
    return

main()
