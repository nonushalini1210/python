class Student:
    def __init__(self,sfirst,slast,sid):
        self.sfirst = sfirst
        self.slast = slast
        self.sid = sid
        self.email = sfirst + '.' + slast + '@grd.edu'

    def fullname(self):
        return '{} {}'.format(self.sfirst,self.slast)
    
   
def main():
    std01 = Student('John','Jones',1001)
    std02 = Student('Linda','Whare',2002)
    print(std01.email)
    print(std02.email)
    print('------')
    print(std01.fullname())
    print(std02.fullname())
main()
