import datetime
import time
def main():
    x = datetime.datetime.now()
    print(x)
    print('-------')
    t = datetime.date.today()
    print('today is: ',t)
    print('-------')
    d = time.time()
    print('current time is: ',d)
    return
main()
