def stl10():
    cm = ','
    a = input('type something in: ')
    b = input('type something in: ')
    c = input('type something in: ')
    d = input('type something in: ')
    x = input(' inset commas 1=yes 0=no :')
    if x == '0':
        line = a + b + c + d
    else:
        line = a + cm + b + cm  + c + cm + d
    print('\n',line,'\n')
def main():
    ans = 'Y'
    while ans.upper()=='Y':
        stl10()
        ans=input(' again y/n :')
main()
