def chkalnum(ss):
    if (ss.isalnum()):
        print(ss, ' - YES alphanumeric')
    else:
        print(ss, ' - not alphanumeric')
    return  
def chkalpha(ss):
    if (ss.isalpha()):
        print(ss, ' - YES alphabetic')
    else:
        print(ss, ' - not pure alphabetic')
    return
def chknum(ss):
    if (ss.isnumeric()):
        print(ss, ' - YES numeric')
    else:
        print(ss, ' - not numeric')
    return  
def chkdigit(ss):
    if (ss.isdigit()):
        print(ss, ' - YES digits')
    else:
        print(ss, ' - not digits')
    return  
def chkdecimal(ss):
    if (ss.isdecimal()):
        print(ss, ' - YES decimal number')
    else:
        print(ss, ' - not decimal')
    return
def main():
    print('\n'*50)
    str01 = ' '
    ans = 'y'
    while ans.upper() == 'Y':
        str01=input('enter characters -> ')
        chkalnum(str01)
        chkalpha(str01)
        chknum(str01)
        chkdigit(str01)
        chkdecimal(str01)
        ans = input('Another test (y/n):')
main()
