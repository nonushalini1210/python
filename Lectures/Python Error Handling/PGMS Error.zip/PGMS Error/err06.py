def main():
    area = 0
    try:
        length = int(input('enter number: '))
        height = 2
        area = length * height
    except ValueError:
        print(' value error')
    except:
        print(' unknown error')
    print(' Area is -> ', area)
main()
