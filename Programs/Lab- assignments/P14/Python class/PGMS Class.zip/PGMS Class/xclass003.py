class Student:
    year = 1
    def __init__(self,sfirst,slast,sid,syear):
        self.sfirst = sfirst
        self.slast = slast
        self.sid = sid
        self.syear = syear
        self.email = sfirst + '.' + slast + '@grd.edu'

    def fullname(self):
        return '{} {}'.format(self.sfirst,self.slast)
    
    def nextyear(self):
        #year = 1
        nyear = int(self.syear) + self.year
        self.syear = nyear
def main():
    std01 = Student('John','Jones',1001,1)
    std02 = Student('Linda','Whare',2002,1)
    
    print(std01.fullname(),' year:', std01.syear)
    std01.nextyear()
    print(std01.fullname(),' year:', std01.syear)

    #print(std01.__dict__)
    #print(Student.__dict__)
main()
