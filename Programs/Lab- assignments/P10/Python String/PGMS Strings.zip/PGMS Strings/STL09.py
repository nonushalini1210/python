import datetime
def somefunc():
    print('\n***** function does something')
    return
def pgm():
    print('program start ',datetime.datetime.now())
    ans = 'y'
    while (ans.upper() == 'Y'):
        somefunc()
        ans = input('\nAgain? enter y=yes, n==no :')
    print('program done ',datetime.datetime.now())
    return
pgm()

        
