def nextex(a):
    print('\n'*a)
    aa = input('hit the enter key to continue')
    print('\n'*1)
def main():
    print('')
    s = "28212"
    print('is ',s,', alpha: ',s.isalpha())
    nextex(1)
    s = "282.12"
    print('is ',s,', alpha: ',s.isalpha())
    nextex(1)    
    s = "32ladk3"
    print('is ',s,', alpha: ',s.isalpha())
    nextex(1)    
    s = "loiuyt"
    print('is ',s,', alpha: ',s.isalpha())
    nextex(1)
    s = "$^&*^"
    print('is ',s,', alpha: ',s.isalpha())
    nextex(1)    
 
main()

