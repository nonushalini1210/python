def testtype(a):
    if type(a) is int:
        print('Passed an integer')
    else:
        print(' -- not an integer --')
    return
def main():
    a = input('enter a word: ')
    testtype(a)
    print(type(a))
    print('-------')
    a = int(input('Enter a whole number: '))
    testtype(a)
    print(type(a))
    print('-------')
    a = float(input('Enter a decimal number: '))
    testtype(a)
    print(type(a))
main()
