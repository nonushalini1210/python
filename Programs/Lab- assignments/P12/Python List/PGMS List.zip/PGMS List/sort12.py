def spacing(a):
    print('\n' * a)
    return
def sortit(arr):
    # brr=sorted(arr)
    brr=sorted(arr,reverse=True)
    return brr
def showarray(srr):
    y=len(srr)
    print('number of elements -> ',y)
    print(srr)
    return
def printsep():
    print
    print('--------------------')
    print
    return
def main():
    spacing(40)
    arrmain = [11,44,77,2,9,15]
    printsep()
    print('orginal list')
    showarray(arrmain)
    bb=sortit(arrmain)
    printsep()
    print('sorted list')
    showarray(bb)
    spacing(5)
    return
main()
