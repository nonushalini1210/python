import keyword
import sys
def main():
    help("modules")
    keylist = keyword.kwlist
    print (keylist)
    print('------------\n')
main()
    
    
