def main():
    length = input('Enter length: ')
    height = input('Enter height: ')
    try:
        length = float(length)
        height = float(height)
        area = length * height
        print(' Area is -> ', area) 
    except:
        area=-1
        print('input not correct data type')
main()
