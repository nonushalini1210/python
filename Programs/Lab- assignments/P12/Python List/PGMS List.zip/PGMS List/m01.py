import random
rows=4
cols=4
def main():
    import random
    values = [[0,0,0,0],
              [0,0,0,0],
              [0,0,0,0],
              [0,0,0,0]]
    for r in range(rows):
        for c in range(cols):
            values[r][c] =random.randint(1,100)
    print(values)
    listlen = len(values)
    print('number of elements: ',listlen)
main()
