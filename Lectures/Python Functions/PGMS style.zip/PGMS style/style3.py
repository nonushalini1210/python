# Program add two numbers
def add(x, y):
    t = x + y
    return t
# Take input from the user
def main():
    num1 = int(input("Enter first number: "))
    num2 = int(input("Enter second number: "))
    #  addd two numbers
    t = add(num1,num2)
    print(num1,"+",num2,"=", t)
    return
main()
