from datetime import date
from datetime import time
from datetime import datetime
def logpgm(logfile,cond):
    dt = datetime.today()
    dts = str(dt) + '\n'
    if cond == 0:
        ps = 'program started '+ '\n'
    else:
        ps = 'program ended '+ '\n'
    logfile.write(ps)
    logfile.write(dts)
    return
def openfiles():
    code = 0
    try:
        filein ='C:/data6/pgmdata/testfile8.txt'
        datafilein = open(filein,'r')
    except:
        code = 1
    try:
        fileout ='C:/data6/pgmdata/testfile7out.txt'
        datafileout1 = open(fileout,'w')
    except:
        code = 3
    try:
        filelg ='C:/data6/pgmdata/testfile7log.txt'
        datafileout2 = open(filelg,'w')
    except:
        code = 3
    return(datafilein,datafileout1,datafileout2, code)
def closefiles(fi,fo,fg):
    fi.close()
    fo.close()
    fg.close()
    return
def errorchk(code):
    msg='unknown file processing error'
    if code == 1:
        msg = ' error - input file'
    elif code == 2:
        msg = 'error - output file 1'
    else:
        msg = 'error - output file 2'
    return msg
def validline(line):
    msg = ''
    if line.count(',') != 3:
        msg = 'Recrd format invalid'
    return msg
def main():
    msg = ''
    rcdcnt = 0 
    (infile,outfile,logfile,code)=openfiles()
    if code == 0:
        line = ''
        newline = ''
        line=infile.readline()
        while line != '':
            print(line)
            msg = validline(line)
            if msg =='':
                (a,b,c,d) =line.split(',')
                print(' A is: ' + a)
                print(' B is: ' + b)
                print(' C is: ' + c)
                print(' D is: ' + d)       
                line=infile.readline()
                rcdcnt = rcdcnt+1
                newline = a + ',' + d 
                outfile.write(newline)
            else:
                print(msg)
                print('record error: ',line)
                print(' Program terminated due to errors')
                line=''
    else:
        errorchk(code)
        msg = logpgm(logfile,0)
        print(msg)
    print('number of records: ',rcdcnt)
    logpgm(logfile,1)
    closefiles(infile,outfile,logfile)
main()

