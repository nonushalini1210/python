def main():
    x = 5
    numb = 1
    print('\n***while start***\n\n')
    while (numb < x):
        print('--number-> ',numb)
        numb = numb + 1
    else:
        print('\nloop done')
    print('\nprogram terminated')
    return
main()

