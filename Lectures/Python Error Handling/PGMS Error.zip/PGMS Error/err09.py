def gethigh():
    tall=int(input('Enter height: '))
    if tall < 0:
        raise ValueError('invalid height can not be negative')
    return tall

def main():
    again = "y"
    while again =='y':
        height = 0
        length = 0
        area = 0
        try:
            length = int(input('enter number: '))
            height = gethigh()
            area = length * height
        except ValueError as exerr:
            print(' Value error detected')
            print(' Error on value of height')
            print(exerr)
        except:
            print(' unknown error')
        print(' Area is -> ', area)
        again = input('Again (y/n): ')
main()
