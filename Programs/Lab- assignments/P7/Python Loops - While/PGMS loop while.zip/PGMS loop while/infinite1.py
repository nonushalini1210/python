def main():
    x = 1
    y = 2
    z = 1
    while (z < 5):
        a = x * y
        print('a->',a)
        x = x + 1
        z = z - 1
    print('--done--')
main()
