def main():
    print('pgm started')
    filenamein ='c:/data6/pgmdata/testfile1.txt'
    rcdcnt = 0
    with open(filenamein,'r') as infile:
        for line in infile:
            rcdcnt = rcdcnt+1
            line = line.strip()
            print (line)
    print('\n'+ 'Number of records read: ' + str(rcdcnt))
    print (' ---done')
main()
