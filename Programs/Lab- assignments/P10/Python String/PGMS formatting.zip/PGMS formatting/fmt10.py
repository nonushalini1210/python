nm = "Jane Doe"
print('Name is: {}'.format(nm))
print
fn = 'Jimmy'
ln = 'Johns'
print('First Name is {}'.format(fn))
print('Last Name is: {}'.format(ln))
print('Name: {}  {}'.format(fn,ln))
