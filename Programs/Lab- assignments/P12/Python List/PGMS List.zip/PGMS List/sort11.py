def spacing(a):
    print('\n' *a)
    return
def sortit(arr):
    arr.sort()
    # arr.sort(reverse = True)
    return
def showarray(arr):
    print('list-. ',arr)
    return
def printsep():
    print
    print('--------------------')
    print
    return
def main():
    spacing(40)
    arrmain = [11,44,77,2,9,15]
    printsep()
    showarray(arrmain)
    sortit(arrmain)
    printsep()
    showarray(arrmain)
    printsep()
    spacing(10)
    return
main()
