# pass 2 variables
def addit(x,y):
    a = x + y
    return a
def main():
    numb1 = float(input('enter number ->'))
    numb2 = float(input('enter number ->'))           
    tot = addit(numb1,numb2)
    print('total is -> ',tot)
main()
