slen1 = len("abcd")
print('length of text: ', slen1)
aa=input('hit enter key to continue')
city = 'New York'
clen = len(city)
print('length of city: ', clen)   
