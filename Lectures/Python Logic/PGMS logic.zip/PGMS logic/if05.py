def main():
    x = int(input("enter an integer: "))
    if x < 0:
       x = 0
       print('Negative changed to zero')
    elif x == 0:
       print('Zero')
    else: 
       print('positive number')
main()
