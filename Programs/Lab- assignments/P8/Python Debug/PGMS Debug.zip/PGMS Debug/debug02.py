def blkln(a):
      print('\n'*a)
      return
def main():
      blkln(60)
      balance=100.00
      payment=float(input('enter payment: '))
      blkln(10)
      newbalance = balance - paymnet
      print('starting balance: ',balacne)
      print(' Payment: ',payment)
      print('New Balance: ',newbalnace)
      blkln(10)
main()
