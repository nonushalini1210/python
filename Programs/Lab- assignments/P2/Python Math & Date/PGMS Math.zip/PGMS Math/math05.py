import math
def main():
    mm = 10
    t25 = 25
    t5=5
    rr=3
    ee = 2
    zz=math.ceil(mm/rr)
    print('math.ceil - ',zz)
    aa = input('hit enter key to continue')      
    zz=math.fmod(t25,rr)
    print('math.fmod - ',zz)
    aa = input('hit enter key to continue')      
    zz=math.pow(t5,rr)
    print('math.pow - ',zz)
    aa = input('hit enter key to continue')      
    zz=math.sqrt(t25)
    print('math.sqrt - ',zz)
    aa = input('hit enter key to continue')      
    zz=math.pi 	 
    print('math.pi - ',zz)
    aa = input('hit enter key to continue')
    zz=math.sin(mm)
    print('math.sin - ',zz)
    aa = input('hit enter key to continue')      
    zz=math.cos(mm)
    print('math.cos - ',zz)
    aa = input('hit enter key to continue')      
    
main()

