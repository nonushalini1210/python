def genin():
    input('\nhit enter to continue\n')
    return
def sel001():
    print(' \n * selection 1\n')
    genin()
    return
def sel002():
    print(' \n * * selection 2\n')
    genin()
    return
def sel003():
    print(' \n * * * selection 3\n')
    genin()   
    return
def sel004():
    print(' \n * * * * selection 4\n')
    genin()
    return
def sel005():
    print(' \n * * * * * selection 5\n')
    genin()
    return
def displaymenu():
    print('\n'*20)
    print(' '*10,' select action ')
    print(' '*10,'----------------')
    print (' '*10,'1  one')
    print (' '*10,'2  two')
    print (' '*10,'3  three')
    print (' '*10,'4  four')
    print (' '*10,'5  five')    
    print(' ')
    print (' '*10,'9   Quit\n')
    return
def menu():
    selection = 0
    while (selection != '9'):
        displaymenu()
        selection = input(' Select 1,2,3,4,5 or 9 [to quit]: ')
        if (selection =='1' ):
            sel001()
        elif (selection == '2'):
            sel002()
        elif (selection == '3'):
            sel003()
        elif (selection == '4'):
            sel004()
        elif (selection == '5'):
            sel005()            
        elif (selection == '9'):
            return
        else:
            print(' invalid selection, try again')
    return
def main():
    ans='y'
    while (ans == 'Y') or (ans == 'y'):
        menu()
        ans = input('Again y/n ; ')
        print('--done')
    return
main()
