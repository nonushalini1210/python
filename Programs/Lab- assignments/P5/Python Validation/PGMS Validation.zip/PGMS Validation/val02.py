def nextex(a):
    print('\n'*a)
    aa = input('hit the enter key to continue')
    print('\n'*1)
def main():
    print('')
    s = "28212"
    print('is ',s,', decimal: ',s.isdecimal())
    nextex(1)
    s = "282.12"
    print('is ',s,', decimal: ',s.isdecimal())
    nextex(1)    
    s = "aaaaaa"
    print('is ',s,', decimal: ',s.isdecimal())
    nextex(1)    
    s = "Mo3 nicaG el l22er"
    print('is ',s,', decimal: ',s.isdecimal())
    nextex(1)    
main()

