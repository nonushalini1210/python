class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age
def main():
    indiv = Person('john smith',40)
    psname = indiv.name
    psage = indiv.age
    print('Name is: ',psname)
    print('Age is: ',psage)
    return
main()
