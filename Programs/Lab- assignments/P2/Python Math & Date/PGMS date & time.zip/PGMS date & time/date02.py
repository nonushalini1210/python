import datetime
def main():
    x = datetime.datetime.now()
    print(x)
    print('-------')
    t = datetime.date.today()
    print('today is: ',t)
    return
main()
