class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age
    def showname(self):
        print('Name is: ',self.name)
    def incage(self):
        fage = float(self.age)
        fage = fage + 1
        print('Next year age is: ', fage)
def main():
    ename = input('Enter name: ')
    eage = input('Enter age: ')
    indiv = Person(ename,eage)
    psname = indiv.name
    psage = indiv.age
    indiv.showname()
    indiv.incage()
    return
main()
