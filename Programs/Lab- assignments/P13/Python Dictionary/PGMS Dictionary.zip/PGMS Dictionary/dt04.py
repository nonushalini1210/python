def main():
     # set up dictionary
     dt01 = { 1: 'one',
                    2: 'two',
                    3: 'three',
                    4: 'four'}
     print('Dictionary example')
     print(dt01)
     a = 5
     b = 'five'
     dt01[a] = b
     print(dt01)
     input('enter to continue')
     a = 5
     b = 'xxxxxxxxxx'
     dt01[a] = b
     print(dt01)
main()
