def main():
    for x in range(1,50,1):
        print('x -> ',x)
        if x == 10:
            print('time to break')
            break
    print(' -- done --')
main()
