import numpy as np

# linear array
arr = np.array([1, 2, 3])
print("Linear Array: \n",arr)
 
# 2 x 2 array
arr = np.array([[1, 2, 3],
                [4, 5, 6]])
print("2 x 2 Array: \n", arr)

# 3 x 3 array
arr3 = np.array([[2,4,6],
                [22,44,66],
                [222,444,666]])

print('3 x 3 Array: \n', arr3)
