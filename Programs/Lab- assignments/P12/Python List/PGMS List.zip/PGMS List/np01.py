import numpy as np

# linear array
arr = np.array([1, 2, 3])
print("Linear Array: \n",arr)
 
# 2 x 2 array
arr = np.array([[1, 2, 3],
                [4, 5, 6]])
print("2 x 2 Array: \n", arr)
# 3 x 3 array
arr = np.array([[1, 2, 3],
                [4, 5, 6],
                 [7,8,9]])
print("3 x 3 Array: \n", arr)
# 4 x 4 array
arr = np.array([[1, 2, 3,8],
                [4, 5, 6,6],
                 [7,8,9,3],
                [11,22,33,1]])
print("4 x 4 Array: \n", arr)
