def main():
    x = 1
    y = 2
    z = 0

    while (z < 5):
        a = x * y
        print("z is: ", z, '     a->',a)
        x = x + 1
        z = z + 1
    print('--done--')
main()
