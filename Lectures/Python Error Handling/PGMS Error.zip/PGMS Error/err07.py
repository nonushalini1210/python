def main():
    area = 0
    length=-1
    try:
        length = input('enter number: ')
        length = int(length)
        height = 2
        area = length * height
    except (ValueError, TypeError):
        print(' DATA ERROR')
        print('invald input',length)
    except:
        print(' unknown error')
    #finally:
        #area=-1
    print(' Area is -> ', area)
main()
