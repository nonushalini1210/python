def main():
     dt01={1:'one',2:'two',3:'three',4: 'four'}
     dt02={'A':1,'B':2,'C':3,'D':4,'E':5,'F':6}
     print('Dictionary example')
     print('----dt01 ----')
     print(dt01)
     input('Enter key to continue') 
     zz = len(dt01)
     print('Number of sets in dt01 is: ', zz)
     input('Enter key to continue')
     print('----dt02 ----')
     print(dt02)
     input('Enter key to continue') 
     zz = len(dt02)
     print('Number of sets in dt02 is: ', zz)           
main()

