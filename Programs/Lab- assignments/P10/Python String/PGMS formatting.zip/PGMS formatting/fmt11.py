nm = 101
print('Numbr is: {:d}'.format(nm))
print
fn = 202  
ln = 555
print('First number is {:d}'.format(fn))
print('Last number is: {:d}'.format(ln))
print('Name: {:d}   {:d}'.format(fn,ln))
