A =2
B = 5
C = "5"
D = 'A'
E = A
input('hit enter to continue')
if A > B:
    z = 'True'
else:
    z = 'False'
print('A > B  ', z)
if C > D:
    z = 'True'
else:
    z = 'False'
print('C > D  ', z)
if D == A:
    z = 'True'
else:
    z = 'False'
print('D ==A  ', z)
#if C <= B:
#    z = 'True'
#else:
#    z = 'False'
print('C <= B  ', 'Error')
if B == E:
    z = 'True'
else:
    z = 'False'
print('B == E  ', z)
if D != B:
    z = 'True'
else:
    z = 'False'
print('D != B  ', z)
if C == 7:
    z = 'True'
else:
    z = 'False'
print('C == 7  ', z)
if E >= 6:
    z = 'True'
else:
    z = 'False'
print('E >= 6  ', z)


















