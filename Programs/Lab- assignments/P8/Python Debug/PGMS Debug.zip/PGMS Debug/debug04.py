def main():
      n1 = 0
      n2 = 0
      n1 = input("Enter number 1: ")
      n2 = input('Enter number 2: ')
      n3 = n1 + n2
      print(n1, ' + ', n2, ' = ', n3)
      return
main()
