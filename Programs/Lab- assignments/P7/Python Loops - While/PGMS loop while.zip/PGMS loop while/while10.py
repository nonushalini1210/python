def sel001():
    print('you selected 1 \n')
    input('hit enter to continue\n')
    return
def sel002():
    print('you selected 2 \n')
    input('hit enter to continue\n')
    return
def displaymenu():
    print('\n'*20)
    print(' '*10,'1  select number one')
    print(' '*10,'2 select number two')
    print('\n')
    print(' '*10,'9 quit')
    print('\n'*5)
    return     
def menu():
    selection = 0
    while (selection != 9):
        displaymenu()
        selection = input(' Select 1,2 or 9 [to quit]: ')
        if (selection =='1' ):
            sel001()
        elif (selection == '2'):
            sel002()
        elif (selection == '9'):
            print('--- quit the menu')
            return
        else:
            print(' invalid selection, try again')
    return
def main():
    ans = 'y'
    while (ans == 'y'):
        menu()
        ans = input('again y/n ')
    print('program terminated')
    return
main()

