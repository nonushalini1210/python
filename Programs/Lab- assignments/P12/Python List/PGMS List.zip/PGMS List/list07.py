
def main():
    numblist = [5,15,25,66,33,22,99,88,2,44]
    print('number of elements-> ',len(numblist))
    print(numblist)
    print('-------')
    ans = input('enter to continue')
    aa = int(input('Enter integer: '))
    if aa  in numblist:
        print('true ',aa, ' is in list')
    else:
        print('false ',aa, ' not in list')
    print('------')
    ans = input('enter to continue')
    if aa  not in numblist:
        print('true ', aa, ' is not in list')
    else:
        print('false ',aa, ' is in list')
main()
