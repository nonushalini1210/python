import keyword
import sys
import builtins

def main():
    help("modules")
    keylist = keyword.kwlist
    print (keylist)
    print('------------\n')
    print(sys.builtin_module_names)
    print("--------------")

    builtin_types = [getattr(builtins, d)
                         for d in dir(builtins)
                         if isinstance(getattr(builtins, d), type)]
    print(builtin_types)  
main()
    
    
