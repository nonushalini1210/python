def main():
    print('Program start')
    #cc =0.0
    cc=0
    for aa in range(1,11,1):
        zz = input('hit enter key to continue')
        print(" aa -> ",aa)
        for bb in range(1,11,1):
            cc = aa / bb
            print(aa, ' / ', bb, ' = ',cc)
    print('Program done')
main()

