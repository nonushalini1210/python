nm = "Jane Doe"
print('Name is: %s' % (nm))
print
fn = 'Jimmy'
ln = 'Johns'
print('First Name is %s' % (fn))
print('Last Name is: %s' % (ln))
print('%s      %s' % (fn,ln))
