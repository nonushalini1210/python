 
def main():
    x = 5
    print('x = ', x)
    x = x + 1
    print('x = ', x)
    zz = input('hit enter key to continue')
    x = 5
    print('x = ', x)
    x += 1
    print('x = ', x)
    zz = input('hit enter key to continue')
main()

