def getinput():
    a=float(input('Enter a number: '))
    return a
def calc1():
    print('calc 1')
def calc2():
    print('calc 2')
def displayit():
    print('Display results')
def main():
    getinput()
    print('number entered is: ', a)
    calc1()
    calc2()
    displayit()
    return
main()
