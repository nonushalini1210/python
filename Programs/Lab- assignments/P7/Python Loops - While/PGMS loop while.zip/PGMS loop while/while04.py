def main():
    x =1
    while x <100:
        print('x -> ',x)
        if x == 25:
            print('time to break')
            break
        x = x + 1
    print(' -- done --')
main()
