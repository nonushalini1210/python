def closefiles(datafile):
    datafile.close()
def openfiles(filename, how):
    datafile=""
    try:
        datafile = open(filename, how)
    except FileNotFoundError:
        print(' ERROR - File not found: ', filename)
    except:
        print('unknown error')
    return datafile
def main():
    filename ='c:/data6/pgmdata/testfile5x.txt'
    rcdcnt = 0
    infile = openfiles(filename,'r')
    if (infile!=""):
        line=infile.readline()
        print('here are the sales amoount: ')
        while line != '':
            print(' line before split: ' + line)
            a,b,c =line.split(',')
            print(' A is: ' + a)
            print(' B is: ' + b)
            print(' C is: ' + c)         
            line=infile.readline()
            rcdcnt = rcdcnt+1
        closefiles(infile)
        print('\n'+ 'Number of records read: ' + str(rcdcnt))
    else:
        print(' program ending error in file')
    print (' ---done')
main()

