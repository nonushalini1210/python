
def main():
    ans = "y"
    while (ans.upper() == "Y"):
        # statements
        print('yes')
        ans = input('Continue (y/n)? ')
    return
main()
