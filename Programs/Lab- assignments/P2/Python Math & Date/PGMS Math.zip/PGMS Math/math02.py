def main():
    aa = int(input('Enter a number: '))
    bb = int(input('Another number: '))
    cc = int(input('One more number: '))
    zz = aa + bb - cc * 5
    print('aa + bb - cc * 5 is: ', zz)
    xx = (aa + bb - cc) * 5
    print('(aa + bb - cc) * 5 is: ',xx)
    ww = aa + (bb - cc) * 5
    print('aa + (bb - cc) * 5 is: ', ww)
main()

