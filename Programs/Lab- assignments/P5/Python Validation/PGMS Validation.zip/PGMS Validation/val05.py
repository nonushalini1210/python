def nextex(a):
    print('\n'*a)
    aa = input('hit the enter key to continue')
    print('\n'*1)
def main():
    print('')
    s = "28212444"
    print('len ',s,', is ',len(s))
    nextex(1)
    s = "282.12"
    print('len ',s,', is ',len(s))
    nextex(1)    
    s = "32la   dk3"
    print('len ',s,', is ',len(s))
    nextex(1)    
    s = "loiuyt"
    print('len ',s,', is ',len(s))
    nextex(1)
    s = "$^&*^"
    print('len ',s,', is ',len(s))
    nextex(1)    
    s = ""
    print('len ',s,', is ',len(s))
    nextex(1)    
  
main()
