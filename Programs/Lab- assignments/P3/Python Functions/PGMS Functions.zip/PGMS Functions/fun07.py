def getinput():
    print('get input ')
def calc1():
    print('calc 1')
def calc2():
    print('calc 2')
def displayit():
    print(' Display results')
def main():
    getinput()
    calc1()
    calc2()
    displayit()
    return
main()
