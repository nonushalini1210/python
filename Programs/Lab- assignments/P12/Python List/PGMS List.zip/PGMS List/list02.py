def main():
    numb = [3, 6, 9, 12, 15, 17,55,88]
    len01 = len(numb)
    print(numb)
    print('number of elements -> ',len01)
main()
