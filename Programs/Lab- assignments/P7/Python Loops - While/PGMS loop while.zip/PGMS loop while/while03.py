def main():
    x = 5
    m = 3
    out1 = 1
    while (out1 < x):
        in1 = 1
        print(' outside-> ',out1)
        while (in1 < m):
            print('        inside-> ',in1)
            in1 = in1 + 1
        out1 = out1 + 1
    print('program terminated')
    return
main()

