def main():
   w = ''
   w = input('enter a letter --> ')
   if (w == 'b'):
       print('w contains a b')
main()
