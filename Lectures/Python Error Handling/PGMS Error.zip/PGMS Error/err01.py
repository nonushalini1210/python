def main():
    print('\n'*5)
    length = input('Enter length: ')
    height = input('Enter height: ')
    area = length * height
    print(' Area is -> ', area)
main()
