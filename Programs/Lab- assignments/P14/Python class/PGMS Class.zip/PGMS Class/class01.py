class ex1:
    x=5

def main():
    p1 = ex1()
    a = p1.x
    print('-> ',a)
    return
main()
