import time
def sel001():
    print(' \nselection 1\n')
    return
def sel002():
    print(' \nselection 2\n')
    return
def sel003():
    print(' \nselection 3\n')
    return
def sel004():
    print(' \nselection 4\n')
    return
def sel005():
    print(' \nselection 5\n')
    return
def displaymenu():
    print('\n'*25)
    print(' '*10,' select action ')
    print(' '*10,'----------------')
    print (' '*10,'1  one')
    print (' '*10,'2  two')
    print (' '*10,'3  three')
    print (' '*10,'4  four')
    print (' '*10,'5  five')    
    print(' ')
    print (' '*10,'9   Quit\n')
    return
def menu():
    selection = 0
    displaymenu()
    selection = input(' Select 1,2,3,4,5 or 9 [to quit]: ')
    if (selection =='1' ):
        sel001()
    elif (selection == '2'):
        sel002()
    elif (selection == '3'):
        sel003()
    elif (selection == '4'):
        sel004()
    elif (selection == '5'):
        sel005()            
    elif (selection == '9'):
        return
    else:
        print(' invalid selection, try again')
    time.sleep(10)
    return
def main():
    menu()
    return
main()
