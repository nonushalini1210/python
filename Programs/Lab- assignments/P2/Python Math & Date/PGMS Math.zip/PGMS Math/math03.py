def main():
    t =2
    y=3
    b=4
    u=5
    p=6
    e=7
    aa = t + y * b - u / p + e
    print('t + y * b – u / p + e  is:',aa)
    zz=input('hit enter key to continue')
    aa = (t + y) * b - u / p + e
    print('(t + y) * b – u / p + e  is:',aa)
    zz=input('hit enter key to continue')
    aa = t + (y * b - u ) / p + e
    print('t + (y * b – u ) / p + e  is:',aa)
    zz=input('hit enter key to continue') 
main()

