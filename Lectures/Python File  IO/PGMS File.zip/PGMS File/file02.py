def main():
    print('pgm start')
    filenameout ='c:/data6/pgmdata/ph.txt'
    outfile = open(filenameout,'w')
    outfile.write(' John Paul Jones')
    outfile.write('Dave Hal Smith')
    outfile.write('Fast Eddy Burke')
    outfile.close()
    print('pgm done')
main()
