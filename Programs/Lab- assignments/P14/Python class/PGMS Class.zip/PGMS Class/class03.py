class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age
def main():
    ename = input('Enter name: ')
    eage = input('Enter age: ')
    indiv = Person(ename,eage)
    psname = indiv.name
    psage = indiv.age
    print('Name is: ',psname)
    print('Age is: ',psage)
    return
main()
