import keyword
def main():
    print(keyword.kwlist)
    print
    print( help('modules'))
    return
main()

 
