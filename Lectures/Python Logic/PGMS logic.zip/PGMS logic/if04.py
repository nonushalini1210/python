def main():
    m=int(input('enter a number -> '))
    if(m>=10):
        if (m>=20):
            print('greater than 20')
        else:
            print('between 10 -20')

    else:
        if (m>=5):
            print('greater than 5')
        else:
            print('less than 5')
main()
