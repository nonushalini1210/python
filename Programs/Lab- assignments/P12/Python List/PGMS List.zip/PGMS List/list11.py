def main():
    filename ='c:/temp/testfile7.txt'
    rcdcnt = 0
    datafile = open(filename,'r')
    line=datafile.readline()
    while (line != ''):
        comcnt = line.count(',')
        print('Record: ', line)
        if (comcnt == 3):
            v1 =line.split(',')
            print(' A is: ' + v1[0])
            print(' B is: ' + v1[1])
            print(' C is: ' + v1[2])
            print(' D is: ' + v1[3])
        else:
            print('record missing fields\n')
        line=datafile.readline() 
        rcdcnt = rcdcnt+1
    datafile.close()
    print('\n'+ 'Number of records read: ' + str(rcdcnt))
    print (' ---done')
main()
