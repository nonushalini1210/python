def spacer(a):
    print('\n'*a)
    return
def valid(chk):
    if len(chk) == 0:
        return -1
    fchk = float(chk)
    if fchk < 0:
        return -1
    return fchk
def trace3():
    print('payroll calculator')
    hours = input('enter hours: ')
    rate = input('hourly rate; ')
    fhours = valid(hours)
    print('-------------------')
    print('Number of hours worked: ', hours)
    print('Hourly rate of Pay: ',rate)
    print('--------------------')      
    if fhours > 0:
        frate = valid(rate)
        if frate > 0:
            pay = fhours * frate
            print('Gross amout:  ',pay)
        else:
            print:('invalid hours')
    else:
        print('invalid rate')
    print('---------------------')
    return
def main():
    spacer(2)
    ans='y'
    while ans =='y':
        trace3()
        ans = input('Again y=yes, n=no -> ')
        spacer(2)
    return
main()
                    

