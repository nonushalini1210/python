
def main():
    numblist = [5,15,25,66,1,33,22,'a',99,88,2,44]
    print('number of elements-> ',len(numblist))
    print(numblist)
    print('-------')
    print('highest -> ',max(numblist))
    print('lowest -> ',min(numblist))
    total = sum(numblist)
    print('Total -> ', total)
main()
