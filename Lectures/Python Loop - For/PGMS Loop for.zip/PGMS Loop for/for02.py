def spacer():
    z=input('hit enter key to continue')
    print('--------------')
    return    
def main():
    spacer()
    srt = int(input('enter loop start number: '))
    end = int(input('enter loop ending: '))
    incdec = int(input('enter increment or decrement: '))
    spacer()          
    for c in range(srt,end,incdec):
        print('c ->',c)
    spacer()
main()
