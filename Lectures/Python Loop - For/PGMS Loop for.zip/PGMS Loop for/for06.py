def main():
    limit = int(input('enter limit: '))
    for x in range(1,limit,1):
        print('x -> ',x)
        if x == 10:
            print('time to break')
            break
    else:
        print(' Else - loop done')
    print(' -- done --')
main()
