class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age
    def showname(self):
        print('Name is: ',self.name)
    def incage(self):
        fage = float(self.age)
        fage = fage + 1
        print('Next year age is: ', fage)
    def showdata(self):
        print('Name is: ',self.name)
        print('Age is: ',self.age)
