def blkln(a):
      print('\n'*a)
      return
def sepln(a):
      print('-'*a)
      return
def main():
      Cel = 0.0
      blkln(60)
      fah = float(input('Enter Fahrenheit: '))
      sepln(20)
      cel = (fah - 32) * 5/9
      print('Celsius: ',cel)
      sepln(20)
      cel = fah - 32 * 5/9
      print('Celsius: ',cel)
      sepln(20)
      cel = (fah - 32 * 5)/9
      print('Celsius: ',cel)
      sepln(20)
      blkln(5)
      return
main()
