def clrscn(a):
    print('\n' * a)
    return

def main():
    xx = 5
    clrscn(xx)
    print(' --top--')
    clrscn(xx)
    print('--bottom--')
    return

main()
