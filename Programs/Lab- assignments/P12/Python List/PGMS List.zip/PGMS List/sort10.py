def bubblesort(arr):
    outer = len(arr)
    inner = outer -1
    while outer > 0:
        index =0
        while index <= inner-1:
            if arr[index] > arr[index +1]:
                temp = arr[index]     
                arr[index] = arr[index +1]
                arr[index+1]=temp
            index = index+1
        outer = outer-1
    return
def showarray(arr):
    print('List -> ',arr)
    return
def spacing(a):
    print('\n' * a)
    return
def printsep():
    print
    print('--------------------')
    print
    return
def main():
    spacing(30)
    arrmain = [11,44,77,2,9,15]
    printsep()
    showarray(arrmain)
    bubblesort(arrmain)
    printsep()
    showarray(arrmain)
    printsep()
    spacing(10)
    return
main()
