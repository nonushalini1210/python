def main():
    a = 5
    b = 3
    c = a + b
    if (c > 5):
        print('C is greater than 5')
    print('---------')
main()
