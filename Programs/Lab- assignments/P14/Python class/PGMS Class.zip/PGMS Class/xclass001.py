class Student:
    pass
def main():
    sdt01 = Student()   # instance 1
    sdt02 = Student()   # instance 2

    print('std01: ',sdt01)
    print('std02: ',sdt02)
main()
