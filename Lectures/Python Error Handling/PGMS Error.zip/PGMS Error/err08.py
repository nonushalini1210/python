def gethigh():
    tall=int(input('Enter height: '))
    if tall < 0:
        raise ValueError('invalid height')
    return tall
def main():
    area = 0
    try:
        length = int(input('enter number: '))
        height = gethigh()
        area = length * height
    except ValueError as exerr:
        print(exerr)
    except:
        print(' unknown error')
    finally:
        area=-1
        print(' alway executed')
    print(' Area is -> ', area)
main()
