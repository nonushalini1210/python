from Person import Person
def main():
    ename = input('Enter name: ')
    eage = input('Enter age: ')
    indiv = Person(ename,eage)
    psname = indiv.name
    psage = indiv.age
    indiv.showname()
    indiv.incage()
    indiv.showdata()
    print('--------------')
    eage = input('Enter corrected age: ')
    indiv.age = 50
    indiv.showdata()
    return
main()
