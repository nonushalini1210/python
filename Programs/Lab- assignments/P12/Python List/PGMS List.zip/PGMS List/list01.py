def main():
    numb = [2,4,6,8]
    for x in range (0,4,1):
        print(x, ' index has value of:',numb[x])
main()
