# regaular and static methods
# grade whole number
# year (semester)
class Student:
    NumOfStudents = 0
    year = 0
    def __init__(self,sfirst,slast,sid,syear):
        self.sfirst = sfirst
        self.slast = slast
        self.sid = sid
        self.syear = syear
        self.email = sfirst + '.' + slast + '@grd.edu'

        Student.NumOfStudents += 1

    def fullname(self):
        return '{} {}'.format(self.sfirst,self.slast,self.syear)
    
    def nextyear(self):
        self.syear = float(self.syear + self.year)

    @classmethod
    def gradelevel(cls,grade):
        cls.year = grade
        
      
    
def main():
    print('\n'*5)
    print('---------')
    std01 = Student('John','Jones',1001,1.0)
    std02 = Student('Linda','Whare',2002,1.0)

    print(std01.fullname(), '  grade: ',std01.syear)
    print(std02.fullname(), '  grade: ',std02.syear)
    print('----------------------')
    std01.gradelevel(2)
    std01.nextyear()
    print(std01.fullname(), '  grade: ',std01.syear)
    print(std02.fullname(), '  grade: ',std02.syear) 
main()
