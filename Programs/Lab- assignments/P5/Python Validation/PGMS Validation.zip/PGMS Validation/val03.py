def nextex(a):
    print('\n'*a)
    aa = input('hit the enter key to continue')
    print('\n'*1)
def main():
    print('')
    s = "28212"
    print('is ',s,', digit: ',s.isdigit())
    nextex(1)
    s = "282.12"
    print('is ',s,', digit: ',s.isdigit())
    nextex(1)    
    s = "aaaaa"
    print('is ',s,', digit: ',s.isdigit())
    nextex(1)    
    s = "KK *$* ll ()"
    print('is ',s,', digit: ',s.isdigit())
    nextex(1)    
main()

 

