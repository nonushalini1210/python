def main():
      print('\n'*30)
      str01 = ' '
      str01=input('enter a sentence -> ')
      aa = len(str01)
      print(' length of text is: ',aa, '\n')
      ans = input('hit enter to continue')
      
      numb1 = str01.count('t')
      
      print('Sentence is: ', str01,'\n')
      print("Number is t's is: ",numb1)
      ans = input('hit enter to continue')
      
      numb2 =  str01.find('tt')
      print(' \nPosition of tt is -> ',numb2)
      ans = input('hit enter to continue')
      
      str99 = 'g'

      numb2 =  str01.find(str99)
      print(' \nPosition of first g is -> ',numb2)
      ans = input('hit enter to continue')
      
      str02 = str01.replace('little','big')
      print('\nnew sentence is -> ',str02)
main()
