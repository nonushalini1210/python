nm = 101
print('Numbr is: %d' %(nm))
print
fn = 202.99
ln = 555
print('First number is %d' %(fn))
print('Last number is: %d' %(ln))
print('Name: %d    %d'% (fn,ln))
