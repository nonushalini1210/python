
## input routine
def input1(msg):
    indata = input(msg)
    return indata

## Processing
def process1():
    msg = "Enter a number: "
    num = input1(msg)
    (sw1,b) = valid1(num)
    return (sw1,b)

##  validation 
def valid1(num):
    err = 0
    b = 0
    try:
        b = float(num)
        if (b >0):
            err = 0
        else:
            err = 1
    except:
        err = 1
    return (err,b)

## main line
def main():
    ans = 'y'
    total = 0
    while(ans.upper() == 'Y'):
        (sw1,num) = process1()
        if (sw1 == 0):
            print('Number: ',num)
            total = total + num
        else:
            print(' ***** Invalid INPUT')
        msg = 'Continue (y/n)? '    
        ans = input1(msg)
    print('-------')
    print('total is: ', total)
    return
main()
