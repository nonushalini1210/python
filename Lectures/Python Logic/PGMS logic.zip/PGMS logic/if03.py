def main():
    a=2
    m=3
    b=int(input('enter a number -> '))
    k=int(input('enter a number -> '))
    if (a > b) and (m==k):
        print(' --TRUE --')
    else:
        print(' false ')
main()
