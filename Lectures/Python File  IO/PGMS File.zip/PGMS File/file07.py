#
# note forward slash must be used for file and path
#
#  back slash is used as escape character

def main():
    filename ='c:/data6/pgmdata/testfile5.txt'
    rcdcnt = 0
    datafile = open(filename,'r')
    line=datafile.readline()
    print('here are the sales amount: ')
    while line != '':
        rcdcnt = rcdcnt+1
        print(' line before split: ' + line)
        a,b,c =line.split(',')
        print(' A is: ' + a)
        print(' B is: ' + b)
        print(' C is: ' + c)         
        line=datafile.readline()

    datafile.close()
    print('\n'+ 'Number of records read: ' + str(rcdcnt))
    print (' ---done')
main()

