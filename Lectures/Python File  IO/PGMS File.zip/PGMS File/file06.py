def main():
    print('pgm start')
    filename ='c:/data6/pgmdata/testfile3.txt'
    appfile = open(filename, 'w')
    ans = 'Y'
    print(appfile)
    while (ans.upper() == 'Y'):
       name1 = input('enter name: ')
       addr = input('enter address: ')
       city = input('Enter city name: ')             
       state = input('enter state code: ')
       zip = input('Enter zip code; ')
       rcd = name1 +',' + addr + ',' + city + ',' + state
       rcd = rcd + ',' + zip + '\n'
       appfile.write(rcd)
       ans = input('More input (y/n): ')
    appfile.close()
    print('pgm end')
main()
