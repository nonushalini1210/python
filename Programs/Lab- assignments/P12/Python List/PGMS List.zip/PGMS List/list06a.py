
def main():
    numblist = ['q','z','h','a','g']
    print('number of elements-> ',len(numblist))
    print(numblist)
    print('-------')
    print('highest -> ',max(numblist))
    print('lowest -> ',min(numblist))
    #total = sum(numblist)
    #print('Total -> ', total)
main()
