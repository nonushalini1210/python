print('\n'*5)
str01 = 'wright'
for ch in str01:
    print("   ",ch)
ans = input('\nhit enter to continue\n')
print('-'*20)
str02 = input('enter text, word or something: ')
for ch in str02:
    print('     ',ch)
print('xxx'*20)
