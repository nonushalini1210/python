import keyword
def main():
    print( help('modules'))
    return
main()
