
def main():
    print(help('print'))
main()




 # "modules", "keywords", "symbols", or "topics"

 
