def doubleit(vv):
    dd = vv *2
    return dd

def main():
       aa = 20
       bb = doubleit(aa)
   
       print(' double of ', aa, ' is ', bb)
       return

main()
