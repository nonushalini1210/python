def getinput():
    pass
def calc1():
    pass
def calc2():
    pass
def displayit():
    pass
def main():
    getinput()
    calc1()
    calc2()
    displayit()
    return
main()
