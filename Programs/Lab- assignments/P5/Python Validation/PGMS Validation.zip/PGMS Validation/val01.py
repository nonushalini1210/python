def main():
    print('\n'*2)
    str01=input('enter characters -> ')
    if (str01.isalnum()):
        print('input is alpha numeric')
    else:
        print('input is NOT alphanumeric')
    if (str01.isalpha()):
        print('input is alpha')
    else:
        print('input NOT alpha->')
    if (str01.isnumeric()):
        print('input is numeric')
    else:
        print('input is NOT numeric')
main()


