import time
import datetime
def main():
    print('\n'*25)
    x = datetime.datetime.now()
    print(x)
    print('-------')
    t = datetime.date.today()
    print('today is: ',t)
    print('-------')
    c = time.time()
    print('current time is: ',c)
    print('-------')
    c=time.localtime()
    print('current time is: ',c)
    print('-----')
    r = time.localtime()
    print("time: ", r)
    print("year:", r.tm_year)
    print("hour: ", r.tm_hour)
    print("minute: ",r.tm_min)
    return
main()
