nm = 101.6
print('Numbr is: %6.2f' %(nm))
print
fn = 202.99 
ln = 555.00007
print('First number is %6.2f' %(fn))
print('Last number is: %6.2f' %(ln))
print('Name: %6.2f  %6.2f'% (fn,ln))
