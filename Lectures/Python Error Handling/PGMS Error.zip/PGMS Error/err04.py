def main():
    
    length = input('Enter length: ')
    height = input('Enter height: ')
    try:
        area = length * height
        print(' Area is -> ', area)
    except:
        print(' data invalid')

main()
